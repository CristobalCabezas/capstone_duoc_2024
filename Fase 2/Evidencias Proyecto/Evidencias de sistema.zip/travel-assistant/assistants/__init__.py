# from tools.hotel_tools import get_availability_for_hotels
# from tools.excursion_tools import get_availability_for_excursions

# __all__ = ["get_availability_for_hotels", "get_availability_for_excursions"]