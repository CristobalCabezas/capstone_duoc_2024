<script setup lang="ts">
import { storeToRefs } from 'pinia'
import { PromovedServicesSearchData } from '~/types/service'
import dayjs from 'dayjs'
import LoaderExperienceCard from '~/components/ui/loaders/LoaderExperienceCard.vue'
import { ref, watch, nextTick, onMounted, computed } from 'vue'
import { useI18n } from 'vue-i18n'

const hostnameStore = useHostnameStore()
useHead({
  title: `Home - ${hostnameStore.hostname?.title}`,
})

const searchDate = computed(() => {
  const date = new Date(new Date().setDate(new Date().getDate() + 15))
  return dayjs(date).format('YYYY-MM-DD')
})

const authStore = useAuthStore()

const data: PromovedServicesSearchData = {
  adults: 2,
  country: 'Chile',
  currency: authStore.getCurrency === 'CLP' ? 1 : 2,
  service_type: 'excursion',
  travel_date: searchDate.value,
  secondaryCompany: authStore.getSecondaryCompany.id || null,
}
const { t } = useI18n()
const serviceStore = useServiceStore()
const hotelStore = useHotelStore()
const packageStore = usePackageStore()
const loading = ref(false)

watch(
  () => authStore.getCurrency,
  async () => {
    loading.value = true
    data.currency = authStore.getCurrency === 'CLP' ? 1 : 2
    serviceStore.fetchPromovedServices(data)
    hotelStore.fetchPromovedHotels(promovedHotelsPayload.value)
    await packageStore.fetchPromovedPackages(promovedPackagesPayload.value)
    loading.value = false
  }
)

const { getSecondaryCompany } = storeToRefs(authStore)
watch(getSecondaryCompany, () => {
  nextTick(async () => {
    loading.value = true
    data.currency = authStore.getCurrency === 'CLP' ? 1 : 2
    data.secondaryCompany = getSecondaryCompany.value.id || null
    serviceStore.fetchPromovedServices(data)
    hotelStore.fetchPromovedHotels(promovedHotelsPayload.value)
    await packageStore.fetchPromovedPackages(promovedPackagesPayload.value)
    loading.value = false
  })
})

const promovedHotelsPayload = computed(() => {
  return {
    currency: authStore.getCurrency === 'CLP' ? 1 : 2,
    checkin: dayjs().add(15, 'day').format('YYYY-MM-DD'),
    checkout: dayjs().add(16, 'day').format('YYYY-MM-DD'),
    rooms: [
      {
        adults: 2,
        children: 0,
        infants: 0,
        ages: [],
      },
    ],
  }
})

const promovedPackagesPayload = computed(() => {
  const payload = { ...promovedHotelsPayload.value }
  payload.checkin = dayjs().add(30, 'day').format('YYYY-MM-DD')
  payload.checkout = dayjs().add(31, 'day').format('YYYY-MM-DD')
  payload.secondaryCompany = getSecondaryCompany.value.id || null
  return payload
})

onMounted(async () => {
  loading.value = true
  serviceStore.fetchPromovedServices(data)
  hotelStore.fetchPromovedHotels(promovedHotelsPayload.value)
  await packageStore.fetchPromovedPackages(promovedPackagesPayload.value)
  loading.value = false
})
</script>

<template>
  <div
    class="mx-auto mt-0 h-full w-full max-w-7xl px-4 pt-10 transition duration-150 sm:px-6 md:px-8"
  >
    <div class="container mx-auto grid grid-cols-1 gap-12">
      <index-promoved-hotels
        :promoved-hotels-payload="promovedHotelsPayload"
        :loading="loading"
      />
      <index-featured-hotel />

      <index-popular-destinies />
      <index-featured-excursion />

      <div>
        <h2 class="mb-4 text-2xl font-medium text-slate-800">
          {{ t('index.best_activities') }}
        </h2>
        <div
          class="flex gap-4 overflow-x-auto scrollbar-hide md:flex-wrap md:gap-0 xl:gap-4"
        >
          <template v-if="!loading">
            <div
              v-for="service in serviceStore.promovedServices.slice(0, 4)"
              :key="service.id"
              class="w-[290px] md:w-1/2 md:p-2 xl:w-[290px] xl:p-0"
            >
              <experience-card
                class="w-[290px] md:w-full xl:w-[290px]"
                :service="service"
              />
            </div>
          </template>
          <template v-else>
            <div
              v-for="index in 4"
              :key="index"
              class="w-[290px] md:w-1/2 md:p-2 xl:w-[290px] xl:p-0"
            >
              <LoaderExperienceCard class="w-[290px] md:w-full xl:w-[290px]" />
            </div>
          </template>
        </div>

        <div
          class="mt-10 flex gap-4 overflow-x-auto scrollbar-hide md:flex-wrap md:gap-0 xl:gap-4"
        >
          <template v-if="!loading">
            <div
              v-for="service in serviceStore.promovedServices.slice(4, 8)"
              :key="service.id"
              class="w-[290px] md:w-1/2 md:p-2 xl:w-[290px] xl:p-0"
            >
              <experience-card
                class="w-[290px] md:w-full xl:w-[290px]"
                :service="service"
              />
            </div>
          </template>
          <template v-else>
            <div
              v-for="index in 4"
              :key="index"
              class="w-[290px] md:w-1/2 md:p-2 xl:w-[290px] xl:p-0"
            >
              <LoaderExperienceCard class="w-[290px] md:w-full xl:w-[290px]" />
            </div>
          </template>
        </div>
      </div>
      <index-promoved-packages
        v-if="hostnameStore.hostname.features.show_packages"
        :promoved-hotels-payload="promovedHotelsPayload"
        :loading="loading"
      />
      <index-featured-transfer />
    </div>
  </div>
  <the-chat-bot />
</template>

<route lang="yaml">
meta:
  layout: demo
  requiresAuth: true
</route>
