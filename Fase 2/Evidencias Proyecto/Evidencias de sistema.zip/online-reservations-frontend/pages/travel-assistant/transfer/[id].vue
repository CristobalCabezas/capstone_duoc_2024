<script setup lang="ts">
import { InformationCircleIcon } from '@heroicons/vue/20/solid'
import { currencyFormatter } from '~/utils/formatter'
import { SopturService } from '~/types/service'
import { MapPinIcon } from '@heroicons/vue/24/outline'
import dayjs from 'dayjs'
import 'dayjs/locale/es'
import customParseFormat from 'dayjs/plugin/customParseFormat'

const { toTitle } = useGlosa()
const serviceStore = useServiceStore()
const hostnameStore = useHostnameStore()
const headDescription = computed(() => {
  const description = serviceStore.currentService?.descriptions?.d_text_es
  return `${toTitle(description) || 'Description'} - ${
    hostnameStore.hostname?.title
  }`
})

useHead({
  title: computed(() => {
    const title = serviceStore.currentService?.glosas?.g_text_es
    return `${toTitle(title) || 'Transfer'} - ${hostnameStore.hostname?.title}`
  }),
  meta: [
    { name: 'description', content: headDescription },
    { property: 'og:description', content: headDescription },
  ],
})

const authStore = useAuthStore()
const { t, locale } = useI18n()

const route = useRoute()

const router = useRouter()
router.options.scrollBehavior = async (to, from) => {
  if (to.name === from.name && to.params.id === from.params.id) {
    return
  } else return { top: 0, behavior: 'smooth' }
}

const queryParams = ref({
  pax: Number(route.query.pax),
  desde: String(route.query.desde),
  hasta: String(route.query.hasta),
  adults: String(route.query.adults),
  children: Number(route.query.children),
  infants: Number(route.query.infants),
  currency: authStore.getCurrency === 'CLP' ? 1 : 2,
})

const getCountry = computed(() => {
  return route.query.townName !== 'Isla de Pascua' ? 'CHILE' : 'Isla de Pascua'
})

const withError = ref(false)
const loading = ref(false)
const loadingCards = ref(false)
const handleSearch = async () => {
  serviceStore.resetCurrentService()
  if (authStore.getUser) {
    loading.value = true
    loadingCards.value = true
    const payload = {
      ...route.query,
      checkin: String(route.query.desde),
      checkout: String(route.query.hasta),
      townId: Number(route.query.townId),
      serviceType: String(2),
      townName: String(route.query.townName),
      adults: Number(route.query.adults),
      children: Number(route.query.children),
      infants: Number(route.query.infants),
      country: getCountry.value,
    }
    const currency = authStore.getUser.currency
    const searchData = {
      id: Number(route.params.id),
      queryParams: queryParams.value,
      currency: currency,
      secondaryCompany: authStore.secondaryCompany.id || '',
      ciudad: String(route.query.townName),
      tipos: Number(route.query.serviceType),
      townId: Number(route.query.townId),
    }

    try {
      await serviceStore.fetchCurrentService(searchData)
    } catch (error) {
      withError.value = true
    }
    loading.value = false
    await serviceStore.fetchServices({
      queryParams: payload,
      currency: currency,
      secondaryCompany: authStore.secondaryCompany.id || '',
    })
    loadingCards.value = false
  }
}

onMounted(async () => {
  if (
    !route.query.townName ||
    !route.query.desde ||
    !route.query.hasta ||
    !route.query.serviceType ||
    !route.query.adults
  ) {
    router.replace('/404')
    return
  }
  serviceStore.resetCurrentService()
  await handleSearch()
})

const watchParams = computed(() => route.query)
watch(watchParams, () => {
  if (route.name === 'travel-assistant-transfer-id') {
    queryParams.value.desde = String(watchParams.value.desde)
    queryParams.value.hasta = String(watchParams.value.desde)
    queryParams.value.adults = String(watchParams.value.adults)
    queryParams.value.children = Number(watchParams.value.children)
    queryParams.value.infants = Number(watchParams.value.infants)
    handleSearch()
  }
})

watch(authStore.auth, () => {
  queryParams.value.currency = authStore.getCurrency === 'CLP' ? 1 : 2
  handleSearch()
})

watch(
  computed(() => withError.value),
  (error) => {
    if (error) {
      router.replace('/404')
    }
  }
)

const transferTitle = computed(() => {
  try {
    if (serviceStore.currentService) {
      const { g_text_es, g_text_en } = serviceStore.currentService.glosas
      const glosa = locale.value === 'es' ? g_text_es : g_text_en
      return glosa
        .split(' ')
        .slice(1)
        .join(' ')
        .split('/')
        .map((t) => toTitle(t))
        .join(' &#8594; ')
    }
    return 'Transfer'
  } catch (error) {
    return 'Transfer'
  }
})

defineProps<{
  isLoading?: boolean
}>()

dayjs.extend(customParseFormat)

const languages = computed(() => {
  return serviceStore.selectedType?.idioma
    ? serviceStore.selectedType?.idioma.split(/,| o | y \s*/)
    : []
})
const selectedLanguage = ref(languages.value[0] || ('Español' as string))

watch(languages, () => {
  selectedLanguage.value =
    (languages.value[0] as string) || ('Español' as string)
})

const twoWayFileStore = useTwoWayFileStore()

const getGuide = (guide: string) => {
  if (guide === 'Driver/Guide')
    return t('transfer_detail_selector.driver_guide')
  if (guide === 'Driver + Guide')
    return t('transfer_detail_selector.plus_guide')
  return ''
}

const getAvailabilityDays = computed(() => {
  if (serviceStore.currentService) {
    const days = serviceStore.currentService?.availability
    if (days?.length === 0) {
      return days[0]
    } else {
      var availability = ''
      for (let index = 0; index < days.length; index++) {
        availability += t('transfer_detail_selector.' + days[index])
        if (index < days.length - 1) {
          availability += ', '
        } else {
          availability += '.'
        }
      }
      return availability
    }
  }
})

const countPax = computed(() => {
  return Number(route.query.adults) + Number(route.query.children)
})

const salePrice = (service: SopturService) => {
  const price = twoWayFileStore.fileCart.FN
    ? service.sale_price.net_price
    : service.sale_price.sale_price
  if (authStore.getCurrency) {
    return currencyFormatter(authStore.getCurrency, price)
  }
  return price
}
</script>

<template>
  <div class="mx-auto max-w-2xl sm:px-6 sm:pt-4 lg:max-w-7xl lg:px-8">
    <!-- eslint-disable vue/no-v-html -->
    <div
      class="mx-auto flex max-w-6xl flex-col justify-between px-4 sm:px-6 lg:px-8"
    >
      <div class="w-full">
        <div
          class="order-2 col-span-10 w-full sm:order-1 sm:col-span-12 lg:col-span-7"
        >
          <h1
            v-if="serviceStore.currentService"
            class="line-clamp-2 flex w-full items-center text-3xl font-medium text-slate-900"
            v-html="transferTitle"
          />
          <div v-else class="h-9 w-2/3 animate-pulse rounded-xl bg-slate-300" />
        </div>
        <div class="mt-1.5 flex justify-between pb-1 text-sm text-slate-600">
          <span v-if="serviceStore.currentService" class="flex items-center">
            <MapPinIcon class="mr-1 h-4" />
            {{ toTitle(serviceStore.getTownDisplayName) }}, Chile
          </span>
          <div v-else class="h-5 w-40 animate-pulse rounded-md bg-slate-300" />
          <div class="space-y-1">
            <div class="flex w-full justify-end space-x-3"></div>
          </div>
        </div>
      </div>
    </div>

    <div class="mx-auto mt-5 max-w-6xl px-4 sm:px-6 lg:px-8">
      <div class="grid grid-cols-1 gap-8 lg:grid-cols-12">
        <div class="col-span-1 space-y-4 lg:col-span-12">
          <transfer-detail-description />
        </div>
      </div>
    </div>

    <div class="mx-auto mt-10 max-w-6xl px-4 sm:px-6 lg:px-8">
      <div v-if="!loading" class="border-l-4 border-blue-400 bg-blue-50 p-4">
        <div class="flex items-start">
          <div class="flex-shrink-0">
            <InformationCircleIcon
              class="hidden h-5 w-5 text-blue-400 sm:inline-flex"
              aria-hidden="true"
            />
          </div>
          <ul class="list-outside space-y-1 pl-8">
            <li class="text-sm text-blue-700">
              {{ t('page_experience_detail.max_luggage') }}
            </li>
            <li class="text-sm text-blue-700">
              {{
                String(route.query.townName).toLowerCase() === 'santiago'
                  ? t('page_experience_detail.santiago_hotel_zone')
                  : t('page_experience_detail.other_hotel_zone')
              }}
            </li>
          </ul>
        </div>
      </div>
    </div>
    <div class="w-full justify-center">
      <h2 v-if="!loading" class="mt-10 text-base font-medium text-slate-700">
        {{ t('page_experience_detail.available') }}
      </h2>
      <div id="services" class="absolute -top-24"></div>
      <div class="grid grid-cols-1 gap-8 lg:grid-cols-12">
        <div class="col-span-1 lg:col-span-12">
          <div class="grid grid-cols-12 gap-8">
            <div class="col-span-12 lg:col-span-7">
              <div>
                <h2 class="sr-only text-base font-medium text-slate-900">
                  Servicios Disponibles
                </h2>

                <div
                  v-if="serviceStore.currentService"
                  class="mt-4 grid grid-cols-1 gap-y-3"
                >
                  <div
                    v-for="(service, index) in serviceStore.currentService
                      .services"
                    :key="index"
                    class="relative flex min-h-[150px] w-full rounded-lg border bg-white p-4 shadow-sm"
                  >
                    <div class="grid w-full grid-cols-12">
                      <!-- first column: title and price -->
                      <div class="col-span-6">
                        <div
                          class="row-span-1 grid h-full grid-rows-2 content-between"
                        >
                          <!-- title -->
                          <div class="row-start-1">
                            <h3
                              class="line-clamp-1 text-xl font-semibold text-slate-700"
                            >
                              {{
                                !service.is_private
                                  ? t('transfer_detail_selector.regular')
                                  : t('transfer_detail_selector.private')
                              }}
                              {{ getGuide(service.guide) }}
                            </h3>
                            <p class="pt-0 text-xs text-slate-500">
                              {{ t(`detail_option.${service.guide}`) }}
                            </p>
                          </div>

                          <!-- price -->
                          <div class="row-span-1 row-start-2 flex items-end">
                            <div>
                              <div class="space-x-1">
                                <span class="text-2xl font-bold text-slate-700">
                                  {{ salePrice(service) }}
                                </span>
                                <span class="font-semibold text-slate-600">
                                  {{ authStore.getCurrency }}
                                </span>
                              </div>
                              <span
                                v-if="twoWayFileStore.fileCart.FN === null"
                                class="text-sm font-medium text-slate-500"
                              >
                                {{
                                  t('transfer_detail_selector.include_taxes')
                                }}
                              </span>
                              <span
                                v-else
                                class="text-sm font-medium text-slate-500"
                              >
                                {{ t('twoWayFile.net_price') }}
                              </span>
                            </div>
                          </div>
                        </div>
                      </div>

                      <div class="col-span-6 space-y-2">
                        <div class="flex items-center justify-between">
                          <div
                            v-if="countPax < service.price_range.pax_to"
                            class="flex w-fit items-center rounded bg-indigo-600 px-1.5 py-1 text-xs font-medium text-white sm:px-2.5 sm:text-sm"
                          >
                            <span class="leading-4">
                              {{ salePrice(service) }}
                              {{ t('page_results.up_to') }}
                              {{ service.price_range.pax_to }}
                              {{ t('page_results.pax') }}
                            </span>
                          </div>
                        </div>
                        <!-- service language -->
                        <div class="flex items-start space-x-1 text-indigo-600">
                          <p class="text-sm font-bold">
                            {{ t('languages.' + service.idioma) }}
                          </p>
                        </div>

                        <!-- pickup -->
                        <div class="flex items-start space-x-1">
                          <p class="text-sm font-medium text-slate-600">
                            {{ transferTitle + ' ' + t(`details.pickup`) }}
                          </p>
                        </div>

                        <!-- availability -->
                        <div class="flex items-start space-x-1">
                          <p class="text-sm font-medium text-slate-600">
                            {{ getAvailabilityDays }}
                          </p>
                        </div>

                        <!-- one way -->
                        <div class="flex items-center space-x-1">
                          <p class="text-sm font-medium text-slate-600">
                            {{ t('transfer_detail_selector.one_way_transfer') }}
                          </p>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <template v-else>
                  <detail-item-skeleton-loader v-for="i in 3" :key="i" />
                </template>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<route lang="yaml">
meta:
  layout: demo
  requiresAuth: true
</route>
