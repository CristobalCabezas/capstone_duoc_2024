<script setup lang="ts">
import { InformationCircleIcon } from '@heroicons/vue/20/solid'
import { MapPinIcon } from '@heroicons/vue/20/solid'
import 'dayjs/locale/es'
import { Icon } from '@iconify/vue'
import { CalendarDaysIcon, LanguageIcon } from '@heroicons/vue/24/outline'
import { currencyFormatter } from '~/utils/formatter'
import { SopturService } from '~/types/service'

const serviceStore = useServiceStore()

const { toTitle } = useGlosa()
const hostnameStore = useHostnameStore()
const headDescription = computed(() => {
  const description =
    serviceStore.currentService?.descriptions?.d_text_es || 'Description'
  return `${toTitle(description)} - ${hostnameStore.hostname?.title}`
})

useHead({
  title: computed(() => {
    const title = serviceStore.currentService?.glosas?.g_text_es || 'Excursion'
    return `${toTitle(title)} - ${hostnameStore.hostname?.title}`
  }),
  meta: [
    { name: 'description', content: headDescription },
    { property: 'og:description', content: headDescription },
  ],
})

const route = useRoute()
const authStore = useAuthStore()
const { t, locale } = useI18n()

const router = useRouter()
router.options.scrollBehavior = async (to, from) => {
  if (to.name === from.name && to.params.id === from.params.id) {
    return
  } else return { top: 0, behavior: 'smooth' }
}

const queryParams = computed(() => {
  return {
    desde: String(route.query.desde),
    hasta: String(route.query.hasta),
    adults: String(route.query.adults),
    children: Number(route.query.children),
    infants: Number(route.query.infants),
    currency: authStore.getCurrency === 'CLP' ? 1 : 2,
  }
})

const serviceImages = computed(() => {
  if (serviceStore.currentService) {
    if (serviceStore.currentService.images?.length > 0) {
      return serviceStore.currentService.images.map((image, index) => {
        return {
          id: index,
          url: image,
        }
      })
    }
    return [{ id: 1, url: '/placeholders/gallery.jpg' }]
  }
  return [{ id: 1, url: '/placeholders/gallery.jpg' }]
})

const loading = ref(false)
const loadingCards = ref(false)
const getCountry = computed(() => {
  return route.query.townName !== 'Isla de Pascua' ? 'CHILE' : 'Isla de Pascua'
})

const withError = ref(false)
const handleSearch = async () => {
  loading.value = true
  loadingCards.value = true
  if (authStore.getUser) {
    const payload = {
      ...route.query,
      checkin: String(route.query.desde),
      checkout: String(route.query.hasta),
      townId: Number(route.query.townId),
      serviceType: String(route.query.serviceType),
      townName: String(route.query.townName),
      adults: Number(route.query.adults),
      children: Number(route.query.children),
      infants: Number(route.query.infants),
      country: getCountry.value,
    }

    const currency = authStore.getUser.currency
    const searchData = {
      id: Number(route.params.id),
      queryParams: queryParams.value,
      currency: currency,
      secondaryCompany: authStore.secondaryCompany.id || '',
      ciudad: String(route.query.townName),
      tipos: Number(route.query.serviceType),
      townId: Number(route.query.townId),
    }
    try {
      await serviceStore.fetchCurrentService(searchData)
    } catch (error) {
      withError.value = true
    }
    loading.value = false
    await serviceStore.fetchServices({
      queryParams: payload,
      currency: currency,
      secondaryCompany: authStore.secondaryCompany.id || '',
    })
    loadingCards.value = false
  }
}

const getGlosa = () => {
  if (serviceStore.currentService) {
    const service = serviceStore.currentService
    if (locale.value === 'es') return service.glosas?.g_text_es
    else if (locale.value === 'en') return service.glosas?.g_text_en
  }
  return null
}

onMounted(async () => {
  if (
    !route.query.townName ||
    !route.query.desde ||
    !route.query.hasta ||
    !route.query.serviceType ||
    !route.query.adults
  ) {
    router.replace('/404')
    return
  }
  serviceStore.resetCurrentService()
  await handleSearch()
})

const validateChange = (newParams: any, oldParams: any) => {
  return (
    newParams.desde !== oldParams.desde ||
    newParams.hasta !== oldParams.hasta ||
    newParams.adults !== oldParams.adults ||
    newParams.children !== oldParams.children ||
    newParams.infants !== oldParams.infants
  )
}

watch(queryParams, (newParams, oldParams) => {
  if (
    route.name === 'travel-assistant-services-id' &&
    validateChange(newParams, oldParams)
  ) {
    handleSearch()
  }
})

const idWatch = computed(() => route.params.id)

watch(idWatch, () => {
  if (route.name === 'travel-assistant-services-id') {
    handleSearch()
  }
})

watch(authStore.auth, () => {
  handleSearch()
})

watch(
  computed(() => withError.value),
  (error) => {
    if (error) {
      router.replace('/404')
    }
  }
)

defineProps<{
  isLoading?: boolean
}>()

const languages = computed(() => {
  return serviceStore.selectedType?.idioma
    ? serviceStore.selectedType?.idioma.split(/,| o | y \s*/)
    : []
})

const selectedLanguage = ref(languages.value[0] || ('Español' as string))

watch(languages, () => {
  selectedLanguage.value = languages.value[0] as string
})

const twoWayFileStore = useTwoWayFileStore()

const getGuide = (guide: string) => {
  if (guide === 'Driver/Guide')
    return t('transfer_detail_selector.driver_guide')
  if (guide === 'Driver + Guide')
    return t('transfer_detail_selector.plus_guide')
  return ''
}

const getAvailabilityDays = computed(() => {
  if (serviceStore.currentService) {
    const days = serviceStore.currentService?.availability
    if (days?.length === 0) {
      return days[0]
    } else {
      var availability = ''
      for (let index = 0; index < days.length; index++) {
        availability += t('transfer_detail_selector.' + days[index])
        if (index < days.length - 1) {
          availability += ', '
        } else {
          availability += '.'
        }
      }
      return availability
    }
  }
})

const countPax = computed(() => {
  return Number(route.query.adults) + Number(route.query.children)
})

const salePrice = (service: SopturService) => {
  const price = twoWayFileStore.fileCart.FN
    ? service.sale_price.net_price
    : service.sale_price.sale_price
  if (authStore.getCurrency) {
    return currencyFormatter(authStore.getCurrency, price)
  }
  return price
}
</script>

<template>
  <div
    class="mx-auto h-full min-h-[calc(100vh-35vh)] max-w-2xl sm:px-6 sm:pt-4 lg:max-w-7xl lg:px-8"
  >
    <div
      class="mx-auto mb-5 flex max-w-6xl flex-col justify-between px-4 sm:flex-row sm:items-center sm:px-6 lg:px-8"
    >
      <div class="w-full sm:order-none sm:mt-0">
        <div
          class="order-2 col-span-10 w-full sm:order-1 sm:col-span-12 lg:col-span-7"
        >
          <div class="flex">
            <h1
              v-if="serviceStore.currentService && !isLoading"
              class="text-3xl font-medium text-slate-900"
            >
              {{ toTitle(getGlosa()) }}
            </h1>
            <div
              v-else
              class="h-9 w-2/3 animate-pulse rounded-xl bg-slate-300"
            />
          </div>
        </div>
        <div class="mt-3 flex justify-between text-sm text-slate-600 md:mt-0">
          <span
            v-if="serviceStore.currentService && !isLoading"
            class="flex items-center"
          >
            <MapPinIcon class="mr-1 h-4" />
            {{ toTitle(serviceStore.getTownDisplayName) }}, Chile
          </span>
          <div
            v-else
            class="mt-2 h-5 w-40 animate-pulse rounded-md bg-slate-300"
          />
        </div>
      </div>
    </div>

    <base-gallery
      :images="serviceImages || [{ id: 1, url: '/placeholders/gallery.jpg' }]"
      :is-loading="loading"
      title="cts turismo"
    />

    <div class="mx-auto my-6 max-w-6xl px-4 sm:px-6 lg:px-8">
      <div class="grid grid-cols-1 gap-3 lg:grid-cols-12">
        <div class="col-span-12">
          <h3 v-if="!loading" class="font-medium text-slate-700">
            {{ t('page_experience_detail.description') }}
          </h3>
          <div v-else class="h-5 w-24 animate-pulse rounded-md bg-slate-300" />
          <experience-detail-description :is-loading="loading" />
        </div>

        <div class="col-span-12">
          <h3 v-if="!loading" class="mb-6 font-medium text-slate-700">
            {{ t('page_experience_detail.include') }}
          </h3>
          <div
            v-else
            class="h-5 w-[10.5rem] animate-pulse rounded-md bg-slate-300"
          />
          <experience-detail-included :is-loading="loading" />
        </div>
      </div>
    </div>
    <div class="mx-auto max-w-6xl px-4 sm:px-6 lg:px-8">
      <div
        v-if="
          serviceStore.currentService?.services &&
          serviceStore.currentService?.services?.length > 0 &&
          !loading
        "
        class="mx-auto w-full border-l-4 border-blue-400 bg-blue-50 p-4"
      >
        <div class="flex items-center">
          <div class="flex-shrink-0">
            <InformationCircleIcon
              class="hidden h-5 w-5 text-blue-400 sm:inline-flex"
              aria-hidden="true"
            />
          </div>
          <div class="ml-3">
            <p class="text-sm text-blue-700">
              {{
                String(route.query.townName).toLowerCase() === 'santiago'
                  ? t('page_experience_detail.santiago_hotel_zone')
                  : t('page_experience_detail.other_hotel_zone')
              }}
            </p>
          </div>
        </div>
      </div>
    </div>

    <div class="relative mx-auto max-w-6xl px-4 sm:px-6 lg:px-8">
      <div id="services" class="absolute -top-24" />
      <div class="grid grid-cols-1 gap-8 lg:grid-cols-12">
        <div class="col-span-1 mt-6 lg:col-span-12">
          <!--inicio-->
          <div class="flex w-full justify-center">
            <div class="mx-auto mt-6 max-w-6xl px-4 sm:px-6 lg:px-8">
              <h2 v-if="!loading" class="text-base font-medium text-slate-700">
                {{ t('page_experience_detail.available') }}
              </h2>
              <div
                v-else
                class="h-5 w-[10.5rem] animate-pulse rounded-md bg-slate-300"
              />
              <div
                v-if="serviceStore.currentService && !isLoading"
                class="mt-4 grid grid-cols-1 gap-y-3"
              >
                <div
                  v-for="(service, index) in serviceStore.currentService
                    .services"
                  :key="index"
                  class="relative flex min-h-[150px] w-full rounded-lg border border-slate-300 p-4 shadow-sm"
                >
                  <div class="grid w-full grid-cols-12">
                    <!-- first column: title and price -->
                    <div class="col-span-6">
                      <div
                        class="row-span-1 grid h-full grid-rows-2 content-between"
                      >
                        <!-- title -->
                        <div class="row-start-1">
                          <h3
                            class="line-clamp-1 text-xl font-semibold text-slate-700"
                          >
                            {{
                              !service.is_private
                                ? t('transfer_detail_selector.regular')
                                : t('transfer_detail_selector.private')
                            }}
                            {{ getGuide(service.guide) }}
                          </h3>
                          <p class="pt-0 text-xs text-slate-500">
                            {{ t(`detail_option.${service.guide}`) }}
                          </p>
                        </div>

                        <!-- price -->
                        <div class="row-span-1 row-start-2 flex items-end">
                          <div>
                            <div class="space-x-1">
                              <span class="text-2xl font-bold text-slate-700">
                                {{ salePrice(service) }}
                              </span>
                              <span class="font-semibold text-slate-600">
                                {{ authStore.getCurrency }}
                              </span>
                            </div>
                            <span
                              v-if="twoWayFileStore.fileCart.FN === null"
                              class="text-sm font-medium text-slate-500"
                            >
                              {{ t('page_experience_detail.include_taxes') }}
                            </span>
                            <span
                              v-else
                              class="text-sm font-medium text-slate-500"
                            >
                              {{ t('twoWayFile.net_price') }}
                            </span>
                          </div>
                        </div>
                      </div>
                    </div>

                    <div class="col-span-6 space-y-2">
                      <div class="flex items-center justify-between">
                        <div
                          v-if="countPax < service.price_range.pax_to"
                          class="flex w-fit items-center rounded bg-indigo-600 px-1.5 py-1 text-xs font-medium text-white sm:px-2.5 sm:text-sm"
                        >
                          <Icon
                            class="mr-1 hidden h-4 w-4 text-yellow-400 sm:inline-block"
                            icon="ant-design:gift-filled"
                          />
                          <span class="leading-4">
                            {{ salePrice(service) }}
                            {{ t('page_results.up_to') }}
                            {{ service.price_range.pax_to }}
                            {{ t('page_results.pax') }}
                          </span>
                        </div>
                      </div>

                      <!-- service language -->
                      <div
                        class="flex items-start space-x-1 font-bold text-indigo-600"
                      >
                        <div>
                          <LanguageIcon class="h-5 w-5" />
                        </div>
                        <p class="text-sm">
                          {{ t('languages.' + service.idioma) }}
                        </p>
                      </div>

                      <div class="flex items-start space-x-1">
                        <div>
                          <MapPinIcon class="h-5 w-5 text-slate-600" />
                        </div>
                        <p class="text-sm font-medium text-slate-600">
                          <template v-if="service.meet_point !== 'Other'">
                            {{ service.meet_point + ' ' + t(`details.pickup`) }}
                          </template>
                          <template v-else>
                            {{ t('details.other_pickup') }}
                          </template>
                        </p>
                      </div>

                      <!-- availability -->
                      <div class="flex items-start space-x-1">
                        <div>
                          <CalendarDaysIcon class="h-5 w-5 text-slate-600" />
                        </div>
                        <p class="text-sm font-medium text-slate-600">
                          {{ getAvailabilityDays }}
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <template v-else>
                <detail-item-skeleton-loader v-for="i in 3" :key="i" />
              </template>
            </div>
          </div>

          <!--fin-->
        </div>
      </div>
    </div>
  </div>
</template>

<style lang="css" scoped>
/* width */
::-webkit-scrollbar {
  width: 16px;
  height: 16px;
}

/* Track */
::-webkit-scrollbar-track {
  border-radius: 100vh;
  background: #edf2f7;
}

/* Handle */
::-webkit-scrollbar-thumb {
  background: #cbd5e0;
  border-radius: 100vh;
  border: 3px solid #edf2f7;
}

/* Handle on hover */
::-webkit-scrollbar-thumb:hover {
  background: #f7eded;
}
</style>

<route lang="yaml">
meta:
  layout: demo
  requiresAuth: true
</route>
