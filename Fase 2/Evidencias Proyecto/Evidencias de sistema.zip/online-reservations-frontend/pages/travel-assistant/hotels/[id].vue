<script setup lang="ts">
import { storeToRefs } from 'pinia'
import { mergeRoomsNames } from '~/utils'
import { Room } from '~/types/hotel'
import { StarIcon } from '@heroicons/vue/20/solid'
import { MapPinIcon } from '@heroicons/vue/20/solid'
import { Icon } from '@iconify/vue'
import { UsersIcon, CalendarIcon } from '@heroicons/vue/24/outline'
import dayjs from 'dayjs'
import 'dayjs/locale/es'
import customParseFormat from 'dayjs/plugin/customParseFormat'

import { XMarkIcon } from '@heroicons/vue/24/outline'
import { Availability } from '~/types/hotel'
import { currencyFormatter } from '~/utils/formatter'
import { ref } from 'vue'

const hotelStore = useHotelStore()
const twoWayFileStore = useTwoWayFileStore()
const authStore = useAuthStore()
const hostnameStore = useHostnameStore()
const { getCurrency } = storeToRefs(authStore)
const { t, locale } = useI18n()
const { toTitle } = useGlosa()

const route = useRoute()
const router = useRouter()
router.options.scrollBehavior = async (to, from) => {
  if (to.name === from.name && to.params.id === from.params.id) {
    return
  } else return { top: 0, behavior: 'smooth' }
}

const headDescription = computed(() => {
  const description = hotelStore.currentHotel?.policies_description
  return `${description || 'Description'}`
})

useHead({
  title: computed(() => {
    const hotelName = hotelStore.currentHotel?.name
    return `${hotelName || 'Hotel'} - ${hostnameStore.hostname?.title}`
  }),
  meta: [
    { name: 'description', content: headDescription },
    { property: 'og:description', content: headDescription },
  ],
})

const parsedRooms = computed(() => {
  const queryRooms = route.query?.rooms || '[]'
  return typeof queryRooms === 'string' ? JSON.parse(queryRooms) : queryRooms
})

const queryParams = computed(() => {
  if (route.name === 'travel-assistant-hotels-id') {
    return {
      currency: authStore.getCurrency === 'CLP' ? 1 : 2,
      townId: Number(route.query.townId),
      townName: String(route.query.townName),
      rooms: parsedRooms.value,
      checkin: String(route.query.checkin),
      checkout: String(route.query.checkout),
    }
  }
})

const loading = ref(true)
const loadingCards = ref(false)
const handleSearch = async () => {
  loading.value = true
  console.log(queryParams.value)
  loadingCards.value = true
  await hotelStore.fetchHotel(
    queryParams.value as any,
    authStore.getCompany,
    Number(route.params.id)
  )
  loading.value = false
  await hotelStore.fetchHotels(queryParams.value as any)
  loadingCards.value = false
}

const roomsAreValid = computed(() => {
  const rooms: Room[] = parsedRooms.value
  const validation: boolean[] = []
  rooms.forEach((room: any) => {
    if (!room.adults) validation.push(false)
    validation.push('children' in room)
    validation.push('infants' in room)
    validation.push('ages' in room)
  })

  return validation.every((value) => value)
})

onMounted(() => {
  if (
    !roomsAreValid.value ||
    !route.query.townId ||
    !route.query.rooms ||
    !route.query.checkin ||
    !route.query.checkout
  ) {
    router.replace('/404')
    return
  }
  handleSearch()
})

watch(getCurrency, () => handleSearch())
watch(
  computed(() => route.params),
  (newParam, oldParam) => {
    if (route.name === 'travel-assistant-hotels-id') {
      if (newParam.id !== oldParam.id) {
        handleSearch()
      }
    }
  }
)

const validateChange = (newParams: any, oldParams: any) => {
  return (
    newParams.currency !== oldParams.currency ||
    newParams.townId !== oldParams.townId ||
    newParams.townName !== oldParams.townName ||
    newParams.checkin !== oldParams.checkin ||
    newParams.checkout !== oldParams.checkout ||
    JSON.stringify(newParams.rooms) !== JSON.stringify(oldParams.rooms)
  )
}
watch(queryParams, (newParams, oldParams) => {
  const isDetail = route.name === 'travel-assistant-hotels-id'
  if (isDetail && validateChange(newParams, oldParams)) {
    handleSearch()
  }
})

watch(
  computed(() => hotelStore.getError),
  (error) => {
    if (error) {
      router.replace('/404')
    }
  }
)

defineProps<{
  isLoading: boolean
}>()

dayjs.extend(customParseFormat)

const auth = useAuthStore()

const cancellationDate = computed(() => {
  if (hotelStore.currentHotel) {
    const cancellationHours = hotelStore.currentHotel.cancellation
    const checkin = dayjs(route.query.checkin as string)
    const cancellationDate = checkin.subtract(cancellationHours, 'hour')
    return toTitle(cancellationDate.locale(locale.value).format('MMM DD, YYYY'))
  }
  return ''
})

const cancellationDateMobile = computed(() => {
  if (hotelStore.currentHotel) {
    const cancellationHours = hotelStore.currentHotel.cancellation
    const checkin = dayjs(route.query.checkin as string)
    const cancellationDate = checkin.subtract(cancellationHours, 'hour')
    return toTitle(cancellationDate.locale(locale.value).format('MMM DD'))
  }
  return ''
})

const isFreeCancellation = (room: Availability) => {
  if (
    room.cancellation_type === 'Free Cancelation' &&
    hotelStore.currentHotel
  ) {
    const cancellationHours = hotelStore.currentHotel.cancellation
    const checkin = dayjs(route.query.checkin as string)
    const cancellationDate = checkin.subtract(cancellationHours, 'hour')
    if (cancellationDate.diff(dayjs(), 'hour') > 0) {
      return true
    } else return false
  } else return false
}

const countGuests = (rooms: Room[]): number => {
  return rooms.reduce((total, room) => total + room.adults, 0)
}

const countChild = (rooms: Room[]): number => {
  return rooms.reduce((total, room) => total + room.children, 0)
}

const roomChildrenDescription = (rooms: Room[]) => {
  const count = countChild(rooms)
  return count === 0
    ? ''
    : count === 1
    ? `y 1 ${t('component_hotel_detail_room_card.children')}`
    : `y ${count} ${t('component_hotel_detail_room_card.children')}s`
}

const roomGuestsDescription = (rooms: Room[]) => {
  const count = countGuests(rooms)
  return count === 0
    ? ''
    : count === 1
    ? `1 ${t('component_hotel_detail_room_card.adult')}`
    : `${count} ${t('component_hotel_detail_room_card.adult')}s`
}

const showAll = ref(false)

const getBedOptions = (rooms: Room[]) => {
  interface BedOptions {
    bed_options: string
    size: string
    count: number
  }

  const bedOptions: BedOptions[] = rooms.map((room) => {
    return {
      bed_options: room.bed_options,
      size: room.size,
      count: 1,
    }
  })

  const uniqueBedOptions = bedOptions.reduce((acc: BedOptions[], curr) => {
    const index: number = acc.findIndex(
      (item) => item.bed_options === curr.bed_options && item.size === curr.size
    )
    if (index === -1) acc.push(curr)
    else acc[index].count++
    return acc
  }, [])

  const textOptions = uniqueBedOptions.map((item: BedOptions) => {
    const roomCount = item.count > 1 ? ` X${item.count}` : ''
    const roomSize = item.size ? `(${item.size})` : ''
    return `${item.bed_options} ${roomSize}${roomCount}`.trim()
  })

  return textOptions.filter((item) => item !== '')
}

const salePrice = (room: Availability) => {
  const currency = room.currency_id === 1 ? 'CLP' : 'USD'
  const taxMultiplier =
    currency === 'CLP' && twoWayFileStore.fileCart.FN ? 1.19 : 1
  const price = twoWayFileStore.fileCart.FN
    ? room.price_base
    : room.price_value_with_tax
  return currencyFormatter(currency, price * taxMultiplier)
}
</script>

<template>
  <main>
    <!--Header-->
    <div
      class="mx-auto mb-5 flex max-w-6xl flex-col justify-between px-4 sm:px-6 lg:px-8"
    >
      <div class="w-full">
        <div class="flex flex-col items-start lg:flex-row">
          <div class="inline-flex w-full flex-col">
            <div v-if="hotelStore.currentHotel" class="flex w-full space-x-2">
              <h1
                class="flex w-full items-center text-3xl font-medium text-slate-900"
              >
                {{ hotelStore.currentHotel.name }}
                <div class="ml-3 hidden items-center lg:flex">
                  <span
                    class="rounded-xl bg-primary-600 px-2 py-1 text-xs font-semibold text-white"
                  >
                    {{ hotelStore.currentHotel.category.rating }}/5
                  </span>
                  <div class="ml-1 flex space-x-0.5 pr-1.5">
                    <template v-for="i in 5" :key="i">
                      <StarIcon
                        class="h-4"
                        :class="
                          i > hotelStore.currentHotel.category.rating
                            ? 'text-slate-400'
                            : 'text-primary-500'
                        "
                      />
                    </template>
                  </div>
                </div>
              </h1>
            </div>
            <div
              v-else
              class="h-9 w-2/3 animate-pulse rounded-xl bg-slate-300"
            />
            <div class="mt-1.5 flex items-center pb-1 text-sm text-slate-600">
              <MapPinIcon
                v-if="hotelStore.currentHotel"
                class="mr-1 h-4 w-4 flex-none"
              />
              <p v-if="hotelStore.currentHotel" class="line-clamp-1">
                {{ hotelStore.currentHotel.address }}
              </p>
              <div
                v-else
                class="h-5 w-[30rem] animate-pulse rounded-md bg-slate-300"
              />
            </div>
          </div>
          <div class="inline-flex w-full justify-between lg:mt-1.5 lg:w-fit">
            <div
              v-if="hotelStore.currentHotel"
              class="mt-1 flex items-center space-x-2 lg:hidden"
            >
              <span
                class="rounded-xl bg-primary-600 px-2 py-1 text-xs font-semibold text-white"
              >
                {{ hotelStore.currentHotel.category.rating }}/5
              </span>
              <div class="flex space-x-0.5 pr-1.5">
                <template v-for="i in 5" :key="i">
                  <StarIcon
                    class="h-4"
                    :class="
                      i > hotelStore.currentHotel.category.rating
                        ? 'text-slate-400'
                        : 'text-primary-500'
                    "
                  />
                </template>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <!--Galeria-->
    <base-gallery
      :images="
        hotelStore.currentHotel?.images || [
          { id: 1, url: '/placeholders/gallery.jpg' },
        ]
      "
      :is-loading="loading"
      :title="hostnameStore.hostname?.title"
    />

    <div class="mx-auto mt-6 max-w-6xl px-4 sm:px-6 lg:px-8">
      <div class="grid grid-cols-1 gap-8 sm:grid-cols-12">
        <div
          class="col-span-10 mt-2 w-full space-y-4 sm:col-span-12 lg:col-span-12"
        >
          <h2 v-if="!loading" class="font-medium text-slate-700">
            {{ t('page_hotel_detail.details') }}
          </h2>
          <div
            v-else
            class="mt-2 h-4 w-24 animate-pulse rounded-md bg-slate-300"
          />
          <hotel-detail-description :is-loading="loading" />
        </div>

        <div class="col-span-10 w-full space-y-4 sm:col-span-12 lg:col-span-12">
          <h3 v-if="!loading" class="font-medium text-slate-700">
            {{ t('page_hotel_detail.amenities') }}
          </h3>
          <div
            v-else
            class="mt-2 h-4 w-28 animate-pulse rounded-md bg-slate-300"
          />

          <hotel-detail-amenity :is-loading="loading" />
        </div>
      </div>
    </div>

    <div class="flex w-full justify-center">
      <!-- room cards -->
      <div class="mx-auto mt-6 max-w-6xl px-4 sm:px-6 lg:px-8">
        <div v-if="hotelStore.currentHotel && !isLoading">
          <div class="relative grid grid-cols-1 gap-y-3 overflow-x-clip">
            <div
              class="col-span-1 flex justify-between bg-white pb-2 pt-4"
              :class="{
                'sticky top-24 z-10': showAll,
              }"
            >
              <h2
                v-if="!isLoading"
                class="text-base font-medium text-slate-700"
              >
                {{ t('page_hotel_detail.rooms_availability') }}
                ({{ hotelStore.currentHotel.availability.length }})
              </h2>
              <div
                v-else
                class="h-5 w-52 animate-pulse rounded-md bg-slate-300"
              />
              <button
                v-if="hotelStore.currentHotel.availability.length > 3"
                class="text-base font-medium text-slate-400 hover:text-slate-500 hover:underline"
                @click="showAll = !showAll"
              >
                {{
                  !showAll
                    ? t('bookings_page.show_more')
                    : t('bookings_page.show_less')
                }}
              </button>
            </div>

            <!-- BaseAlert for no availability -->
            <BaseAlert
              v-if="
                hotelStore.currentHotel &&
                !isLoading &&
                !hotelStore.selectedRoom.rooms
              "
              alert-type="info"
              class="mt-4"
            >
              <p class="font-normal">
                {{ t('page_results.availability not_found') }}
                <RouterLink
                  :to="{ name: 'results-hotels', query: route.query }"
                  as="span"
                  class="font-bold hover:underline"
                  >{{ t('page_results.search_again') }}</RouterLink
                >
              </p>
            </BaseAlert>

            <!-- Room cards -->
            <div
              v-for="(
                room, index
              ) in hotelStore.currentHotel.availability.slice(
                0,
                showAll ? hotelStore.currentHotel.availability.length : 3
              )"
              :key="index"
              class="relative flex min-h-[150px] w-full cursor-default rounded-lg border border-slate-300 bg-white p-4 shadow-sm"
            >
              <div class="grid w-full grid-cols-12">
                <!-- First column: Room name and price -->
                <div class="col-span-12 sm:col-span-7">
                  <div
                    class="row-span-1 grid h-full grid-rows-2 content-between"
                  >
                    <div class="grid-cols-12 pr-2">
                      <h3 class="text-xl font-semibold text-slate-700">
                        {{ toTitle(mergeRoomsNames(room.details[0].rooms)) }}
                      </h3>
                      <h4
                        v-if="auth.userValidation.is_from_cts"
                        class="text-sm font-medium capitalize text-slate-500"
                      >
                        {{ room.rateplan_names[0] }}
                      </h4>
                    </div>

                    <!-- Price -->
                    <div class="flex items-end">
                      <div>
                        <div class="flex items-end gap-x-1">
                          <span class="text-2xl font-bold text-slate-700">
                            {{ salePrice(room) }}
                          </span>
                          <span class="mb-0.5 font-semibold text-slate-600">
                            {{ room.currency_id === 1 ? 'CLP' : 'USD' }}
                          </span>
                        </div>
                        <span
                          v-if="twoWayFileStore.fileCart.FN === null"
                          class="text-sm font-medium text-slate-500"
                        >
                          {{
                            t('component_hotel_detail_room_card.include_taxes')
                          }}
                        </span>
                        <span v-else class="text-sm font-medium text-slate-500">
                          {{ t('twoWayFile.net_price') }}
                        </span>
                      </div>
                    </div>
                  </div>
                </div>

                <!-- Second column: Room details -->
                <div class="col-span-12 mt-4 space-y-2 sm:col-span-5 sm:mt-0">
                  <!-- Cancellation -->
                  <div class="flex items-center justify-between">
                    <span
                      v-if="isFreeCancellation(room)"
                      class="rounded bg-green-600 px-3 py-1 text-xs font-medium text-white"
                    >
                      {{
                        t('component_hotel_detail_room_card.free_cancellation')
                      }}
                    </span>
                    <div
                      v-else
                      class="flex items-center text-sm font-medium text-slate-600"
                    >
                      <div>
                        <XMarkIcon class="h-5 w-5 stroke-2" />
                      </div>
                      <p>
                        {{
                          t(
                            'component_hotel_detail_room_card.no_free_cancellation'
                          )
                        }}
                      </p>
                    </div>
                  </div>

                  <!-- Breakfast -->
                  <div
                    class="flex items-start gap-x-1"
                    :class="
                      room.mealplan === 'Breakfast Included'
                        ? 'text-green-700'
                        : 'text-slate-600'
                    "
                  >
                    <div>
                      <Icon
                        v-if="room.mealplan"
                        icon="ph:coffee-light"
                        width="20"
                        height="20"
                      />
                    </div>
                    <p class="text-sm font-bold">
                      {{
                        room.mealplan === 'Breakfast Included'
                          ? t(
                              'component_hotel_detail_room_card.include_breakfast'
                            )
                          : t(
                              'component_hotel_detail_room_card.not_include_breakfast'
                            )
                      }}
                    </p>
                  </div>

                  <!-- Cancellation Date -->
                  <div
                    v-if="isFreeCancellation(room)"
                    class="flex items-start gap-x-1"
                  >
                    <div>
                      <CalendarIcon class="h-5 w-5 text-slate-600" />
                    </div>
                    <p class="text-sm font-medium text-slate-600">
                      {{ t('component_hotel_detail_room_card.cancel_until') }}
                      <span class="hidden sm:inline-block">
                        {{ cancellationDate }}
                      </span>
                      <span class="sm:hidden">
                        {{ cancellationDateMobile }}
                      </span>
                    </p>
                  </div>

                  <!-- Pax -->
                  <div class="flex items-start gap-x-1 text-slate-600">
                    <div>
                      <UsersIcon class="h-5 w-5" />
                    </div>
                    <p class="text-sm font-medium">
                      {{ roomGuestsDescription(room.rooms) }}
                      {{ roomChildrenDescription(room.rooms) }}
                    </p>
                  </div>

                  <!-- Bed Options -->
                  <div
                    v-for="(room_detail, i) in getBedOptions(room.rooms)"
                    :key="i"
                    class="flex items-start gap-x-1 text-slate-600"
                  >
                    <div>
                      <Icon
                        v-if="room.mealplan"
                        icon="fluent:bed-24-regular"
                        width="20"
                        height="20"
                      />
                    </div>
                    <p class="flex text-sm font-medium">
                      {{ room_detail }}
                    </p>
                  </div>
                </div>
              </div>
            </div>

            <!-- Show more button -->
            <div
              v-if="hotelStore.currentHotel.availability.length > 3"
              class="flex justify-center"
            >
              <button
                class="mt-3 rounded border border-primary-600 px-4 py-2 text-sm font-medium text-primary-600 hover:shadow"
                @click="showAll = !showAll"
              >
                {{
                  !showAll
                    ? t('bookings_page.show_more')
                    : t('bookings_page.show_less')
                }}
              </button>
            </div>
          </div>
        </div>

        <div v-else>
          <div class="mt-2 h-5 w-48 animate-pulse rounded bg-slate-300" />
          <detail-item-skeleton-loader />
        </div>
      </div>
    </div>
  </main>
</template>

<style lang="css" scoped>
/* width */
::-webkit-scrollbar {
  width: 16px;
  height: 16px;
}

/* Track */
::-webkit-scrollbar-track {
  border-radius: 100vh;
  background: #edf2f7;
}

/* Handle */
::-webkit-scrollbar-thumb {
  background: #cbd5e0;
  border-radius: 100vh;
  border: 3px solid #edf2f7;
}

/* Handle on hover */
::-webkit-scrollbar-thumb:hover {
  background: #f7eded;
}
</style>

<route lang="yaml">
meta:
  layout: demo
  requiresAuth: true
</route>
