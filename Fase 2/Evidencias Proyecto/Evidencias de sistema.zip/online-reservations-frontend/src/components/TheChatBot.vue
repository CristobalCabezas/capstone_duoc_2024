<script setup lang="ts">
import { watch, nextTick } from 'vue'
import { useI18n } from 'vue-i18n'
import { marked } from 'marked'
import { json } from 'stream/consumers'

const { t, locale } = useI18n()
const authStore = useAuthStore()

watch(
  () => authStore.getCurrency,
  async () => {
    await closeChat()
  }
)

watch(
  () => locale.value,
  async () => {
    await closeChat()
  }
)

// Chatbot State
const showChat = ref(false)
const messages = ref<{ text: string; isUser: boolean }[]>([])
const newMessage = ref('')
const isWaitingResponse = ref(false)
const chatContainer = ref<HTMLElement | null>(null) // Reference to the chat container

// Variable to control whether the options buttons are shown
const showOptions = ref(true) // Initially, the options are shown
let approvalNeeded = ref(false)

// Define the WebSocket connection variable
let socket: WebSocket | null = null

// Function to initialize WebSocket connection
const initializeSocket = () => {
  if (!socket || socket.readyState !== WebSocket.OPEN) {
    //socket = new WebSocket('ws://travel-assistant-230257847087.us-central1.run.app/chat')
    socket = new WebSocket('ws://localhost:8100/chat')

    // Handle WebSocket events
    socket.onopen = function () {
      console.log('Connection established with the WebSocket.')
    }

    socket.onmessage = async function (event) {
      if (isWaitingResponse.value) {
        messages.value.pop()
      }

      let json
      try {
        json = JSON.parse(event.data)
        if (json.type == 'approval_needed') {
          approvalNeeded.value = true
        }
      } catch (error) {
        // Do nothing and continue
      }

      const formattedResponse = await formatMarkdownWithLineBreaks(
        event.data || t('index_page.chatbot.error')
      )

      messages.value.push({
        text: formattedResponse,
        isUser: false,
      })

      isWaitingResponse.value = false
    }

    socket.onerror = function (error) {
      console.error('WebSocket error:', error)

      if (isWaitingResponse.value) {
        messages.value.pop()
      }

      messages.value.push({
        text: t('index_page.chatbot.error_message'),
        isUser: false,
      })

      isWaitingResponse.value = false
    }
  }
}

// Function to close the chat, the connection, and clear the history
const closeChat = () => {
  showChat.value = false

  // Close the WebSocket connection if it is open
  if (socket && socket.readyState === WebSocket.OPEN) {
    socket.close()
    socket = null // Reinicio de la variable para futuras conexiones
  }

  // Clear the conversation history
  messages.value = []
  showOptions.value = true // Show the initial buttons again
}

// Function to open/minimize the chat without closing the WebSocket connection
const toggleChat = () => {
  showChat.value = !showChat.value
  if (showChat.value && !socket) {
    initializeSocket()
  }
}

// Method to send messages
const sendMessage = async () => {
  if (
    newMessage.value.trim() !== '' &&
    socket &&
    socket.readyState === WebSocket.OPEN
  ) {
    messages.value.push({ text: newMessage.value, isUser: true })
    const messageToSend = newMessage.value
    newMessage.value = ''

    isWaitingResponse.value = true
    messages.value.push({
      text: t('index_page.chatbot.generating'),
      isUser: false,
    })

    try {
      const data = {
        message: messageToSend,
        language: locale.value == 'en' ? 'English' : 'Spanish',
        currency: authStore.getCurrency,
        token: authStore.auth.user.token,
      }
      socket.send(JSON.stringify(data))
    } catch (error) {
      console.error('Error al enviar el mensaje:', error)

      if (isWaitingResponse.value) {
        messages.value.pop()
      }

      messages.value.push({
        text: t('index_page.chatbot.error_message'),
        isUser: false,
      })

      isWaitingResponse.value = false
    }
  }
}

// Function to select a service and send the corresponding message
const selectService = async (service: string) => {
  showOptions.value = false
  newMessage.value = `${service}`
  await sendMessage()
}

// Watch messages to scroll down when a new message is added
watch(
  messages,
  async () => {
    await nextTick()
    if (chatContainer.value) {
      chatContainer.value.scrollTo({
        top: chatContainer.value.scrollHeight,
        behavior: 'smooth',
      })
    }
  },
  { deep: true }
)

// Function to format Markdown with line breaks
const formatMarkdownWithLineBreaks = async (text: string) => {
  if (text.startsWith('{"type":"text","content":"')) {
    text = text.slice(26, -2)
  }
  if (text.startsWith('{"type":"approval_needed","content":"')) {
    text = text.slice(37, -2)
  }
  text = text.replace(/\\n/g, '<br>')

  let html = marked(text)

  html = (await html).replace(
    /<a href="(.*?)">(.*?)<\/a>/g,
    '<a href="$1" target="_blank" style="color: #87CEEB;">$2 🔗</a>'
  )

  return html
}
</script>

<template>
  <!-- Chat button and window -->
  <div v-if="authStore.userValidation.is_superuser">
    <button
      class="fixed bottom-4 right-4 z-50 flex h-12 w-12 items-center justify-center rounded-l-3xl rounded-t-3xl bg-orange-500 text-white shadow-lg hover:bg-orange-600"
      @click="showChat ? closeChat() : toggleChat()"
    >
      <img src="src/images/Bot_logo.png" alt="Chat Icon" class="h-10 w-10" />
    </button>

    <!-- Main Container -->
    <div
      v-if="showChat"
      name="mainContainer"
      class="fixed inset-0 z-50 flex flex-col bg-gray-200 md:inset-auto md:bottom-16 md:right-10 md:w-80 md:rounded-2xl"
    >
      <!-- Header Container -->
      <div
        name="headerContainer"
        class="relative flex h-16 w-full items-center justify-between bg-orange-500 shadow-lg md:rounded-t-2xl"
      >
        <!-- Logo, Title and BETA Container -->
        <div class="flex items-center space-x-2 p-2">
          <!-- Logo Container -->
          <div name="logoContainer" class="flex items-center">
            <img
              src="src/images/Bot_logo.png"
              alt="Travel Assistant"
              class="h-12 w-12"
            />
          </div>

          <!-- Title Container -->
          <h2 name="titleContainer" class="text-xl font-bold text-white">
            Travel Assistant
          </h2>

          <!-- BETA -->
          <span
            name="beta"
            class="rounded-md bg-white px-2 py-0.5 text-xs font-extrabold text-orange-500"
            >BETA</span
          >
        </div>

        <!-- Minimize and Close -->
        <div class="flex space-x-2 pr-2">
          <button
            name="minimize"
            class="font-bold text-white"
            @click="toggleChat"
          >
            —
          </button>
          <button name="close" class="font-bold text-white" @click="closeChat">
            ✕
          </button>
        </div>
      </div>

      <!-- Chat Container -->
      <div
        ref="chatContainer"
        class="mb-20 h-full w-full flex-1 overflow-auto bg-gray-100 px-2 md:mb-0 md:h-96 md:flex-none"
      >
        <span
          class="ml-5 mt-2 inline-block rounded-r-2xl rounded-t-2xl bg-orange-600 p-2 text-left text-white shadow-lg"
        >
          {{ t('index_page.chatbot.welcome') }}
        </span>
        <div v-for="(message, index) in messages" :key="index" class="my-4">
          <p
            :class="{
              'text-right': message.isUser,
              'text-left': !message.isUser,
            }"
          >
            <span
              :class="
                message.isUser
                  ? 'shadow.lg mr-5 rounded-l-2xl rounded-t-2xl bg-gray-200'
                  : 'ml-5 rounded-r-2xl rounded-t-2xl bg-orange-600 text-white shadow-lg'
              "
              class="inline-block p-2"
              v-html="message.text"
            >
            </span>
          </p>
        </div>

        <div v-if="showOptions" class="mt-4 flex flex-col space-y-2 px-12">
          <button
            class="w-full rounded-lg bg-[#6366f1] py-3 text-white shadow hover:bg-[#4f46e5]"
            @click="selectService(t('index_page.chatbot.select_hotel'))"
          >
            {{ t('index_page.chatbot.hotel') }}
          </button>
          <button
            class="w-full rounded-lg bg-[#6366f1] py-3 text-white shadow hover:bg-[#4f46e5]"
            @click="selectService(t('index_page.chatbot.select_transfer'))"
          >
            {{ t('index_page.chatbot.transfer') }}
          </button>
          <button
            class="w-full rounded-lg bg-[#6366f1] py-3 text-white shadow hover:bg-[#4f46e5]"
            @click="selectService(t('index_page.chatbot.select_excursion'))"
          >
            {{ t('index_page.chatbot.excursion') }}
          </button>
          <button
            class="w-full rounded-lg bg-[#6366f1] py-3 text-white shadow hover:bg-[#4f46e5]"
            @click="selectService(t('index_page.chatbot.select_update'))"
          >
            {{ t('index_page.chatbot.update_button') }}
          </button>
          <button
            class="w-full rounded-lg bg-[#6366f1] py-3 text-white shadow hover:bg-[#4f46e5]"
            @click="selectService(t('index_page.chatbot.select_cancel'))"
          >
            {{ t('index_page.chatbot.cancel_button') }}
          </button>
        </div>
      </div>

      <div v-if="approvalNeeded" class="mt-4 flex flex-col space-y-2 px-12">
        <button
          class="w-full rounded-lg bg-[#6366f1] py-3 text-white shadow hover:bg-[#4f46e5]"
          @click="
            () => {
              selectService(t('index_page.chatbot.approval_yes'))
              approvalNeeded = false
            }
          "
        >
          {{ t('index_page.chatbot.yes_button') }}
        </button>
        <button
          class="w-full rounded-lg bg-[#6366f1] py-3 text-white shadow hover:bg-[#4f46e5]"
          @click="
            () => {
              selectService(t('index_page.chatbot.approval_no'))
              approvalNeeded = false
            }
          "
        >
          {{ t('index_page.chatbot.no_button') }}
        </button>
      </div>

      <!-- Input Container -->
      <div
        name="inputContainer"
        class="fixed bottom-0 w-full bg-gray-200 p-4 md:relative md:rounded-b-lg"
      >
        <div class="flex w-full items-center overflow-hidden rounded">
          <input
            v-model="newMessage"
            class="flex-1 border-none p-3 outline-none disabled:bg-gray-100"
            :placeholder="
              messages.length === 0
                ? t('index_page.chatbot.placeholder_disabled')
                : t('index_page.chatbot.placeholder')
            "
            :disabled="messages.length === 0"
            :class="{ 'cursor-not-allowed': messages.length === 0 }"
            @keyup.enter="sendMessage"
          />
          <button
            class="bg-white p-2 text-2xl text-blue-500 hover:text-blue-600 disabled:cursor-not-allowed disabled:bg-gray-100 disabled:text-gray-400"
            :disabled="messages.length === 0"
            @click="sendMessage"
          >
            ➤
          </button>
        </div>
      </div>
    </div>
  </div>
</template>
