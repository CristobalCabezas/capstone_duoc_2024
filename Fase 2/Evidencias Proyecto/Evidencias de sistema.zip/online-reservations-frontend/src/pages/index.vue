<script setup lang="ts">
import { storeToRefs } from 'pinia'
import { PromovedServicesSearchData } from '~/types/service'
import dayjs from 'dayjs'
import LoaderExperienceCard from '~/components/ui/loaders/LoaderExperienceCard.vue'

const hostnameStore = useHostnameStore()
useHead({
  title: `Home - ${hostnameStore.hostname?.title}`,
})

const searchDate = computed(() => {
  const date = new Date(new Date().setDate(new Date().getDate() + 15))
  return dayjs(date).format('YYYY-MM-DD')
})

const authStore = useAuthStore()

const data: PromovedServicesSearchData = {
  adults: 2,
  country: 'Chile',
  currency: authStore.getCurrency === 'CLP' ? 1 : 2,
  service_type: 'excursion',
  travel_date: searchDate.value,
  secondaryCompany: authStore.getSecondaryCompany.id || null,
}

const { t } = useI18n()
const serviceStore = useServiceStore()
const hotelStore = useHotelStore()
const packageStore = usePackageStore()
const loading = ref(false)

watch(
  () => authStore.getCurrency,
  async () => {
    loading.value = true
    data.currency = authStore.getCurrency === 'CLP' ? 1 : 2
    serviceStore.fetchPromovedServices(data)
    hotelStore.fetchPromovedHotels(promovedHotelsPayload.value)
    await packageStore.fetchPromovedPackages(promovedPackagesPayload.value)
    loading.value = false
  }
)

const { getSecondaryCompany } = storeToRefs(authStore)
watch(getSecondaryCompany, () => {
  nextTick(async () => {
    loading.value = true
    data.currency = authStore.getCurrency === 'CLP' ? 1 : 2
    data.secondaryCompany = getSecondaryCompany.value.id || null
    serviceStore.fetchPromovedServices(data)
    hotelStore.fetchPromovedHotels(promovedHotelsPayload.value)
    await packageStore.fetchPromovedPackages(promovedPackagesPayload.value)
    loading.value = false
  })
})

const promovedHotelsPayload = computed(() => {
  return {
    currency: authStore.getCurrency === 'CLP' ? 1 : 2,
    checkin: dayjs().add(15, 'day').format('YYYY-MM-DD'),
    checkout: dayjs().add(16, 'day').format('YYYY-MM-DD'),
    rooms: [
      {
        adults: 2,
        children: 0,
        infants: 0,
        ages: [],
      },
    ],
  }
})

const promovedPackagesPayload = computed(() => {
  const payload = { ...promovedHotelsPayload.value }
  payload.checkin = dayjs().add(30, 'day').format('YYYY-MM-DD')
  payload.checkout = dayjs().add(31, 'day').format('YYYY-MM-DD')
  payload.secondaryCompany = getSecondaryCompany.value.id || null
  return payload
})

onMounted(async () => {
  loading.value = true
  serviceStore.fetchPromovedServices(data)
  hotelStore.fetchPromovedHotels(promovedHotelsPayload.value)
  await packageStore.fetchPromovedPackages(promovedPackagesPayload.value)
  loading.value = false
})

// Código del chatbot
import { ref, computed, watch, nextTick } from 'vue'
import axios from 'axios'

// Estado del Chatbot
const showChat = ref(false)
const messages = ref<{ text: string; isUser: boolean }[]>([])
const newMessage = ref('')
const isWaitingResponse = ref(false)

// Método para enviar mensajes
const sendMessage = async () => {
  if (newMessage.value.trim() !== '') {
    // Agregar el mensaje del usuario
    messages.value.push({ text: newMessage.value, isUser: true })

    //Limpiar el campo de entrada después de enviar el mensaje
    newMessage.value = ''

    //Mostrar mensaje de "Generando respuesta..."
    isWaitingResponse.value = true
    messages.value.push({ text: 'Generando respuesta...', isUser: false })

    try {
      // Hacer la solicitud POST al backend usando Axios
      const response = await axios.post('http://localhost:8100/chat/', {
        content: messages.value[messages.value.length - 2]?.text || '',
      })

      //Eliminar el mensaje temporal "Generando respuesta..."
      messages.value.pop()

      // Agregar la respuesta del backend al chat
      messages.value.push({
        text:
          response.data.response || 'Lo siento, no pude procesar tu solicitud.',
        isUser: false,
      })
    } catch (error) {
      console.error('Error al enviar el mensaje:', error)

      //Eliminar el mensaje temporal "Generando respuesta..."
      messages.value.pop()

      messages.value.push({
        text: 'Lo siento, ocurrió un error al procesar tu solicitud.',
        isUser: false,
      })
    }

    //Desactivar el mensaje de espera de respuesta
    isWaitingResponse.value = false

    // Limpiar el campo de entrada
    newMessage.value = ''
  }
}
</script>

<template>
  <div
    class="mx-auto mt-0 h-full w-full max-w-7xl px-4 pt-10 transition duration-150 sm:px-6 md:px-8"
  >
    <div class="container mx-auto grid grid-cols-1 gap-12">
      <index-promoved-hotels
        :promoved-hotels-payload="promovedHotelsPayload"
        :loading="loading"
      />
      <index-featured-hotel />

      <index-popular-destinies />
      <index-featured-excursion />

      <div>
        <h2 class="mb-4 text-2xl font-medium text-slate-800">
          {{ t('index.best_activities') }}
        </h2>
        <div
          class="flex gap-4 overflow-x-auto scrollbar-hide md:flex-wrap md:gap-0 xl:gap-4"
        >
          <template v-if="!loading">
            <div
              v-for="service in serviceStore.promovedServices.slice(0, 4)"
              :key="service.id"
              class="w-[290px] md:w-1/2 md:p-2 xl:w-[290px] xl:p-0"
            >
              <experience-card
                class="w-[290px] md:w-full xl:w-[290px]"
                :service="service"
              />
            </div>
          </template>
          <template v-else>
            <div
              v-for="index in 4"
              :key="index"
              class="w-[290px] md:w-1/2 md:p-2 xl:w-[290px] xl:p-0"
            >
              <LoaderExperienceCard class="w-[290px] md:w-full xl:w-[290px]" />
            </div>
          </template>
        </div>

        <div
          class="mt-10 flex gap-4 overflow-x-auto scrollbar-hide md:flex-wrap md:gap-0 xl:gap-4"
        >
          <template v-if="!loading">
            <div
              v-for="service in serviceStore.promovedServices.slice(4, 8)"
              :key="service.id"
              class="w-[290px] md:w-1/2 md:p-2 xl:w-[290px] xl:p-0"
            >
              <experience-card
                class="w-[290px] md:w-full xl:w-[290px]"
                :service="service"
              />
            </div>
          </template>
          <template v-else>
            <div
              v-for="index in 4"
              :key="index"
              class="w-[290px] md:w-1/2 md:p-2 xl:w-[290px] xl:p-0"
            >
              <LoaderExperienceCard class="w-[290px] md:w-full xl:w-[290px]" />
            </div>
          </template>
        </div>
      </div>
      <index-promoved-packages
        v-if="hostnameStore.hostname.features.show_packages"
        :promoved-hotels-payload="promovedHotelsPayload"
        :loading="loading"
      />
      <index-featured-transfer />
    </div>
  </div>

  <!-- Botón y ventana de chat -->
  <div>
    <!-- Botón de chat -->
    <button
      class="fixed bottom-4 right-4 flex h-12 w-12 items-center justify-center rounded-l-3xl rounded-t-3xl bg-orange-500 text-white shadow-lg hover:bg-orange-600"
      @click="showChat = !showChat"
    >
      <img src="src/images/Bot_logo.png" alt="Chat Icon" class="h-10 w-10" />
    </button>

    <!-- Ventana de chat -->
    <div
      v-if="showChat"
      class="fixed bottom-16 right-10 w-80 rounded-lg rounded-b-lg rounded-t-2xl bg-gray-200 shadow-lg transition-all duration-300"
    >
      <div
        class="flex items-center justify-between rounded-t-2xl bg-orange-500 p-4 shadow-lg"
      >
        <div class="flex items-center justify-between">
          <img
            src="src/images/Bot_logo.png"
            alt="Chat Logo"
            class="h-12 w-12"
          />
          <h2 class="pl-3 text-xl font-bold text-white">Travel Assistant</h2>
        </div>
        <button class="text-white" @click="showChat = false">✕</button>
      </div>
      <!-- Mensajes del chat -->
      <div class="mt-4 h-96 overflow-auto bg-white p-2">
        <div v-for="(message, index) in messages" :key="index" class="mb-2">
          <p
            :class="{
              'text-right': message.isUser,
              'text-left': !message.isUser,
            }"
          >
            <span
              :class="
                message.isUser
                  ? 'shadow.lg mr-5 rounded-l-2xl rounded-t-2xl bg-gray-200'
                  : 'ml-5 rounded-r-2xl rounded-t-2xl bg-orange-600 text-white shadow-lg'
              "
              class="inline-block rounded p-2"
            >
              {{ message.text }}
            </span>
          </p>
          <div v-if="message.isUser" class="mt-1 flex items-center justify-end">
            <div
              class="flex h-12 w-12 items-center justify-center rounded-full bg-gray-300 font-bold text-blue-500"
            >
              Yo
            </div>
          </div>
          <div
            v-if="!message.isUser"
            class="mt-1 flex items-center justify-start"
          >
            <div
              class="flex h-12 w-12 items-center justify-center rounded-full bg-orange-500"
            >
              <img src="src/images/Bot_logo.png" class="h-8 w-8" />
            </div>
          </div>
        </div>
      </div>

      <!-- Input del usuario -->
      <div class="rounded-b-lg bg-gray-200 p-4">
        <div class="flex w-full items-center overflow-hidden rounded">
          <input
            v-model="newMessage"
            @keyup.enter="sendMessage"
            class="flex-1 border-none p-3 outline-none"
            placeholder="Escribe un mensaje..."
          />
          <button
            class="bg-white p-2 text-2xl text-blue-500 hover:text-blue-600"
            @click="sendMessage"
          >
            ➤
          </button>
        </div>
      </div>
    </div>
  </div>
</template>

<route lang="yaml">
meta:
  layout: demo
  requiresAuth: true
</route>
